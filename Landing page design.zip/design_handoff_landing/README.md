# Handoff: Unique — Landing / Waitlist Page

## Overview
The public landing page for **Unique**, an AI cold-email platform. Its job is to state the mission ("We make outreach easy"), explain how the product works in five steps, and capture waitlist signups. It is an editorial "front page" — warm paper, ink, one editorial red, a broadsheet masthead — deliberately NOT a glossy gradient SaaS template.

**IMPORTANT — routing:** This landing page is the **initial page** users see. The **sign-in screen only appears once they click "Sign in"** (top-right of the masthead) or "Join the waitlist" → after joining. The landing page is the entry point / root route (`/`); the app (sign-in and everything behind it) lives at a separate route (e.g. `/app` or `/signin`). Do not make sign-in the first thing a visitor sees.

## About the Design Files
The files in `design_files/` are **design references created in HTML** — a working prototype showing the intended look and behavior. They are **not production code to copy directly**. Recreate this design in the target codebase's existing environment (React/Next, Vue, etc.) using its established components and patterns. If no frontend exists yet, Next.js + React is a sensible choice. The full interactive app (sign-in, voice profile, compose, sent/replies) already exists as a separate design system; this handoff covers the **landing page only**.

## Fidelity
**High-fidelity (hifi).** Final colors, typography, spacing, and interactions. Recreate pixel-accurately using the exact token values below. Screenshots in `screens/` show every state.

## Screens / Views

This is a single scrolling page with five bands. See `screens/01`–`06` for the rendered states.

### 1. Masthead (fixed at top of flow, not sticky)
- Full-width bar, `max-width: 1140px` centered, `padding: 0 46px`.
- **Left:** wordmark "Unique" — Newsreader serif, weight 500, 26px, letter-spacing −0.02em — with a red period (`.dot`, color `--red`).
- **Right:** a text "Sign in" link (`.linkbtn`) and a red "Join the waitlist →" button (`.btn-lite`), gap 22px.
- Bottom border: `1.5px solid --ink`.
- **Below it, a dateline strip:** three mono spans, 10.5px, letter-spacing .16em, uppercase, color `--faint`, justified space-between, bottom border `1px solid --rule`: "No. 001 · The voice issue" / "Outbound, in your own hand" / "Private beta · 2026".

### 2. Hero (centered)
- `padding: 54px 0 46px`, `text-align: center`, bottom border `1.5px solid --ink`.
- Kicker: "THE OUTREACH DISPATCH" — mono, 11px, letter-spacing .22em, uppercase, color `--red`, margin-bottom 22px.
- **H1:** "We make outreach *easy*." — Newsreader serif, **96px**, line-height .92, weight 400, letter-spacing −0.035em, max-width 1000px. The word "easy" is `<em>` — italic, color `--red`. The final period is plain ink.
- Sub: "Unique learns how you actually write, finds the right people, and warms up every cold email, so outreach sounds like you, not AI slop." — serif, 22px, line-height 1.5, color `--ink-2`, max-width 620px, margin-top 22px.
- CTA row (margin-top 30px, centered, gap 14px): red "Join the waitlist ⌾" button + "See how it works ↓" text link.
- **Live counter** (see Interactions): boxed, margin-top 26px, `1.5px solid --ink` border, `--paper-lift` background, `padding: 9px 16px`. A pulsing red dot + big serif red number (22px, weight 500) + "already on the waitlist" (mono, 12px, .14em, uppercase, `--ink-2`).
- Proof row (margin-top 30px, gap 30px, centered): three mono items with red Lucide icons — "Gmail read-only" (lock), "You approve every send" (pen-line), "Never stored" (eye-off).

### 3. Section bar
- `padding: 40px 0 20px`, space-between. H2 "How it *works*" (serif 34px, weight 400, "works" is red italic `<em>`, line-height 1.1) + kicker "Five moves · desk to reply".

### 4. Steps (five rows)
- Container `.steps` top border `1.5px solid --ink`.
- Each `.step`: CSS grid `grid-template-columns: 96px 1fr 300px`, gap 34px, `padding: 30px 0`, bottom border `1px solid --rule`, `align-items: start`.
- **Col 1 (number):** serif 60px weight 300 color `--red`, line-height .8; below it a mono label (10px, .18em, uppercase, `--faint`, margin-top 12px): 01 Connect / 02 Learn / 03 Aim / 04 Personalize / 05 Adapt.
- **Col 2 (content):** H3 (serif 26px weight 400, red italic emphasis where marked) + paragraph (17px, line-height 1.6, `--ink-2`, max-width 560px).
- **Col 3 (aside):** left border `1.5px solid --ink`, padding-left 20px. A mono key label (`.k`, 10px .16em uppercase `--faint`) + a small live-looking widget per step.
- **Responsive** (`max-width: 900px`): H1 → 60px; step grid collapses to `60px 1fr` and the aside drops full-width below the text with a top border instead of a left border.

**Exact step copy & asides:**
1. **Connect your Gmail** — "One read-only connection. Unique reads your sent mail to learn your hand. Nothing else in your mailbox is touched, and nothing leaves your account without your say-so." Aside "CONSENT": two mono rows with red icons — 🔒 Read-only scope, ✓ Revoke anytime (shield-check).
2. **Generate your *voice profile*** — "We take down your last 100 sent emails and run them through two layers of analysis. The first reads tone, rhythm and habits; the second checks the draft back against you, until it genuinely sounds like you, not an approximation." Aside "TWO LAYERS": numbered discs ①② + a red-underlined serif-italic clipping "worth 15 minutes next week?".
3. **Give Unique the campaign goal** — "Tell it what the campaign is for. Unique finds the people who should receive it, runs a background check on each, and hyper-personalizes to what it learns, turning cold outreach warm before the first line is written." Aside "GOAL → RECIPIENTS": a pipeline of bordered mono nodes — [Goal](red) → [Find people] → [Background check] → [Warm draft](red).
4. **Every letter, written *for one person*** — "Each recipient gets an email in your voice, shaped by what the background check surfaced. A specific reason you're reaching out, not a mail-merge token. You read the exact words before anything ships." Aside "COLD → WARM": two labeled bar rows — "Generic blast / reply 2%" (12% fill) and "Unique, personalized / reply 41%" (82% fill). Bars: 9px tall, `1px solid --rule-2` track, `--red` fill. (Numbers are illustrative.)
5. **Track replies, adapt on the fly** — "Unique keeps the register of everything sent and who wrote back. When one approach outperforms another, it shifts toward what's working, all inside Unique, online, for now." Aside "LIVE REGISTER": ↩ Reply detection (green icon), 📈 Favors what works (red icon).

### 5. Waitlist block (inverted)
- `.join`: background `--ink`, color `--paper`, `margin: 56px 0`, `padding: 52px 56px`, `position: relative`. A decorative inset frame via `::before` (`inset: 6px`, `1px solid rgba(241,233,214,.28)`).
- Kicker "PRIVATE BETA · LIMITED SEATS" (color `#e0a08c`).
- H2 "Make your outreach *easy*." — serif 46px weight 400, "easy" italic color `#ef8a6e`.
- Paragraph (18px, color `#d8ceba`, max-width 520px).
- Form (margin-top 26px, flex gap 12px, max-width 560px): email input (transparent, bottom border only `1.5px rgba(241,233,214,.4)`, serif 19px, focus border `#ef8a6e`) + red "Reserve my seat ⌾" submit button.
- Fine print (mono 10.5px, uppercase, `rgba(241,233,214,.5)`): "No credit card · One email when it's your turn · Unsubscribe anytime".
- Second live counter row (`.jcount`): pulsing dot + serif number (`#ef8a6e`) + "already reserved a seat".
- **On submit:** the form is replaced by a rotated stamp "✓ You're on the list" (`.stamp`, border/color `#ef8a6e`) and the line "You're **No. N** on the waitlist. We'll write to **{email}** the moment a seat opens." (see `screens/06`).

### 6. Footer
- `.lp-foot`: top border `1.5px solid --ink`, `padding: 26px 0 46px`, space-between, mono 10.5px uppercase `--faint`: "Unique · outbound in your own hand" / "© 2026 · Private beta".

## Interactions & Behavior
- **Anchor nav:** "See how it works ↓" scrolls to `#how`; "Join the waitlist" scrolls to `#join`.
- **Sign in:** the masthead "Sign in" link routes to the sign-in screen (separate route/page). Remember: sign-in is NOT shown until the user clicks it.
- **Live signup counter — starts at 88:**
  - Base is 88. Displayed count = 88 + (number of signups so far).
  - On each waitlist submit, increment by 1 and re-render both counters (hero + waitlist block).
  - In the prototype the increment is persisted client-side in `localStorage` under key `unique_wl_signups` (an integer added to the base). This is a **per-device demo only** — in production this must be a real server-side count (a `waitlist_signups` table / counter API) shared across all visitors. Seed the production counter at 88 to match.
  - The pulsing dot is a CSS `@keyframes pulse` box-shadow animation (1.8s infinite) implying "live".
- **Submit success:** prevent default, store the email, increment count, swap `#joinslot` content for the stamped confirmation showing the person's seat number (`No. {88 + signups}`).
- **Hover:** `.btn-lite` darkens to `--red-deep`; `.linkbtn` turns red with a red underline; buttons nudge `translate(1px,1px)` on `:active`.

## State Management
- `signupCount: number` (server-sourced in production; base 88).
- `joined: boolean` + `email: string` — controls the waitlist block swap to the confirmation state.
- `seatNumber: number` — assigned on successful join (= count after increment).

## Design Tokens
Full set in `design_files/styles.css` → `design_files/tokens/*`. Landing page uses:

**Color**
- `--paper #f1e9d6` (page bg, with a faint 4px radial-dot texture at 2.2% ink)
- `--paper-lift #f8f2e4` (raised surfaces, counter box)
- `--panel #ece2cd`, `--inset #e7dcc4`
- `--ink #211c13` (primary text, borders, waitlist bg), `--ink-2 #544b3a` (secondary text), `--faint #8f8570` (mono labels)
- `--rule #d3c7a9`, `--rule-2 #b7a983` (hairlines)
- `--red #cc3a1c` (the one accent), `--red-deep #a12b12` (hover), `--red-wash #f3d9cf`
- `--green #3f6b4f`, `--amber #b3801a`
- Waitlist-only literals: `#e0a08c` (dim salmon kicker), `#ef8a6e` (bright salmon emphasis/stamp), `#d8ceba` (paper-dim body)

**Type**
- `--font-serif: 'Newsreader', Georgia, serif` — headlines, body, human content. Weights 300/400/500, italics used heavily for emphasis.
- `--font-mono: 'Space Mono', ui-monospace, monospace` — kickers, labels, nav, metadata, buttons. Uppercase + wide letter-spacing (.1em–.22em).
- Both loaded from Google Fonts (see `<link>`/`@import` in the files).
- Scale (px): H1 96 / H2 34 & 46 / H3 26 / body 17–22 / mono labels 10–12.

**Spacing / borders**
- Container max-width 1140px, side padding 46px.
- Rules: 1.5px on major dividers (`--ink`), 1px hairlines (`--rule`).
- No border-radius anywhere except the counter/status dots (circles) — corners are square by design.
- **No drop shadows** — separation is by border + fill only. (The shareable build adds one offset block-shadow on letter sheets elsewhere; the landing page uses none.)

**Motion**
- `@keyframes pulse` — box-shadow ring, 1.8s infinite, on `.dotpulse`.
- Button `transition: transform .08s, background .12s`.

## Assets
- **Icons:** [Lucide](https://lucide.dev) via CDN (`unpkg.com/lucide@latest`), rendered with `lucide.createIcons()`. Icons used: arrow-right, feather, lock, pen-line, eye-off, shield-check, corner-up-left, trending-up, stamp. Use the codebase's existing Lucide package (`lucide-react` etc.) rather than the CDN in production. Stroke width 1.6.
- **Fonts:** Newsreader + Space Mono (Google Fonts).
- **No logo file** — the brand mark is the "Unique." wordmark set in Newsreader with a red period. There is no image logo to import.
- **No photography or illustration** — the design is purely typographic.

## Files
In `design_files/`:
- `landing.html` — the full landing page prototype (structure, styles, counter JS). **Primary reference.**
- `theme.css` — the "Correspondence" design language (fonts, color vars, shared component classes).
- `styles.css` + `tokens/` — the design-system token layer (`colors.css`, `typography.css`, `spacing.css`) that `theme.css` mirrors.

In `screens/` (rendered PNGs):
- `01` hero top · `02` hero counter + steps start · `03` waitlist block (pre-submit) · `04` step 4 detail · `05` waitlist block · `06` waitlist **submitted** confirmation (stamp + seat number).

The live app design system (sign-in, voice profile, compose, sent/replies) lives in `ui_kits/unique/` in the source project if you need the screens behind sign-in.
